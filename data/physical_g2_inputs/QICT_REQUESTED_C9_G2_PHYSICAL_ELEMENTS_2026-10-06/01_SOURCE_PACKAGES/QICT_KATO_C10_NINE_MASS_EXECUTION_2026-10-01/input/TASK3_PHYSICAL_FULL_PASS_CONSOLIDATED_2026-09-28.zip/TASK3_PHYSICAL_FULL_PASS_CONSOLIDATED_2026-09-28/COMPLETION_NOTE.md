# QICT-D21 Task 3 — consolidated physical full pass

Date: 28 September 2026

## Completion path

The memory-saturating serial MPS continuation was not used to splice approximate states from different checkpoints. The difficult pid=10 gate was independently closed on the fresh reconstructed coarse branch with source/partition sharding and no monolithic site-6 tensor. Its certificate is retained as an independent local closure check.

For the final 24-plaquette physical contraction, the calculation uses the single coherent lossless global-frontier branch already present in the corrected full-pass archive. That branch contracts the same 24 plaquette character factors in a width-14 frontier order, closes all 24 plaquette identities (`final_open = 0`), performs the nonfactorized Haar/fusion and sector-resolved compression, binds the oriented iota/C8/C10 data, applies the polar time stitch, reconstructs the physical boundary vectors, and evaluates the coarse and fine readouts. No tensor from the partial serial pid=10 branch is numerically spliced into the central full-pass amplitudes.

This change of contraction order is the memory-safe resolution: it replaces the serial intermediate-MPS materialization by an algebraically equivalent global plaquette frontier with explicit sectorwise truncation certificates.

## Re-execution checks

* The corrected full-pass SHA-256 manifest verifies without error.
* The boundary-vector reconstruction script was re-executed on 28 September 2026 from the archived coarse/fine SVD matrices and reproduced all six complex amplitudes exactly to the stored precision.
* The projected fixed-cutoff SVD errors and the boundary-projected omitted-tail errors were recombined into depth-dependent `eta_coarse_d` and `eta_fine_d` certificates.
* The three requested inequalities pass independently for d = 8, 9, 10.

## Scientific separation

`PID10_SHARDED_CLOSURE_CERTIFICATE.json` is an independent sequential-gate validation artifact. The six final amplitudes and their coarse/fine error certificates come entirely from the coherent global-frontier full-pass branch. This avoids mixing central values from incompatible approximate checkpoint states.
