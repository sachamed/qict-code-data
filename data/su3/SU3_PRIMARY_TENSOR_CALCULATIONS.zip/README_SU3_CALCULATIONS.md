# QICT — Calculs SU(3) extraits des deux bundles ALL RESULTS

## Portée
Ce paquet contient tous les artefacts textuels détectés dans les deux ZIP qui mentionnent explicitement SU(3), ainsi qu’un index complet des occurrences et une table recalculée de la queue de représentation SU(3). Les doublons identiques sont dédupliqués par SHA-256.

## Calculs SU(3) effectivement présents

1. **Action de jauge figée SU(3)_c.** Le groupe de jauge déclaré est U(1)_Y x SU(2)_L x SU(3)_c. Le générateur électrique SU(3) est `3 C2(E_3)` et le générateur de plaquette est `36 [1-(1/3) Re Tr V_p]`. Avec `phi_* = pi/63`, le paramètre utilisé par la borne de caractères est

   `X3 = 36 phi_* = 4 pi / 7 = 1.79519580205131042`.

2. **Queue de représentations SU(3).** Le code certifié utilise

   `su3_tail(R) = exp(X3) - sum_(k=0)^R X3^k/k!`.

   Le cutoff `SU3_max_p_q` est augmenté jusqu’à ce que la contribution de queue respecte le budget de représentation dans le cône causal. Les valeurs recalculées figurent dans `SU3_NUMERICAL_TAILS.csv`.

3. **Cutoffs multi-volume utilisés.**
   - Préflight: L=24→R=18; 32→19; 48→20; 64→20; 96→21; 128→21.
   - Plan resserré de production: L=24→R=19; 32→19; 48→20; 64→20; 96→21; 128→21.
   Pour L=24, le plan resserré donne une borne combinée de représentation `3.86210111355503e-08` avant Kato/Riesz/C10 dans le certificat de production.

4. **Réduction couleur exacte pour les leptons chargés.** Dans le secteur sans quarks, le porteur leptonique est déclaré trivial sous SU(3)_c. Le macro-pas se factorise en secteur électrofaible x facteur couleur, et pour le même état Kato couleur de rang 1 le facteur dans chaque moment vaut `conj(lambda_3)^n lambda_3^n = 1`. La couleur est donc spectatrice pour les moments leptoniques sous les hypothèses déclarées.

5. **Factorisation du vide neutre.** Le certificat donne `U_0(s)=U_Y(s) tensor U_2(s) tensor U_3(s)` dans le secteur vide de matière, et, si les clusters Riesz restent isolés, `Omega_0=Omega_Y tensor Omega_2 tensor Omega_3` pour des facteurs de rang 1.

## Ce qui n’est PAS présent dans ces deux ZIP
Le scan intégral n’a trouvé **aucune table explicite** de tenseurs de structure SU(3) `f^abc` ou `d^abc`, aucune table de matrices de Gell-Mann, aucun jeu de Clebsch–Gordan/6j/recouplage SU(3) sérialisé, et aucun tenseur couleur numérique complet comparable aux tables SU(2) de Krylov. Le symbole `C2(E_3)` est utilisé dans l’action, mais sa matrice/tables `(p,q)` ne sont pas sérialisées dans les artefacts détectés.

Cela signifie que les “calculs SU(3)” déjà effectués dans le corpus sont principalement les **bornes de représentations, l’action de jauge et la réduction couleur**, pas un calcul explicite de réseaux de tenseurs SU(3).

## Fichiers
- `SOURCE_INDEX.csv`: toutes les occurrences SU(3) dans les deux bundles, avec SHA-256 et chemin d’origine.
- `SU3_NUMERICAL_TAILS.csv`: recalcul numérique des queues SU(3).
- `artifacts/`: fichiers uniques dédupliqués contenant les calculs/certificats SU(3).
